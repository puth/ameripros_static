<?php
class transaction{
	function read_file($file){
		echo file_get_contents($file);
	}
	
}
