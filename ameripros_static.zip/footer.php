		</div>
	</div>
	<div class="footer-wrapper">
		<div class="footer">
			<table width="100%; vertical-align:top">
				<tr>
					<td>
						<label class="title">Browse Us</label>
						<ul width="330px">
							<li><a href="product.php">Product</a></li>
							<li><a href="partner.php">Partner</a></li>
							<li><a href="customer.php">Customer</a></li>
							<li><a href="promotion.php">Promotion</a></li>
							<li><a href="order.php">Order</a></li>
						</ul>
					</td>
					<td width="330px">
						<label class="title">Usefull Link</label>
						<ul>
							<li><a href="contact_us.php">Contact us</a></li>
							<li><a href="subscrib.php">Subscribe</a></li>
							<li><a href="feed.php">Feed</a></li>
							<li><a href="FAQ.php">FAQ</a></li>
						</ul>
					</td>
					<td width="330px">
						<label class="title">Join Us</label>
						<ul>
							<li> <a href="https://www.facebook.com/pages/USMouthwash/1453703318209388?ref_type=bookmark">Facebook</a> </li>
							<li><a href="http://www.youtube.com" target="_blank">Youtube</a></li>
							<li><a href="http://www.google.com" target="_blank">Google+</a></li>
							<li><a href="http://linkedin.com" target="_blank">Linked</a></li>
							<li><a href="http://twitter" target="_blank">Twitter</a></li>
						</ul>
					</td>
				</tr>
			</table>
			<div class="copy-right">
				<a href="index.php">AmeriPros Import Export Co.,Ltd &copy; <?php echo date('Y'); ?> </a>
			</div>
		</div>
	</div>
</div>
</body>
</html>